function f=GA_LQR(x)
%参数
m=1835; %车身质量
n=4;
iz=1931; %绕车身转动惯量
mr=50;mf=53;%后轴与前轴质量
kf=28741; %前悬刚度
kr=23741; %后悬刚度
cr=1328;cf=1521; %后悬、前悬阻尼
ktf=322342; %前轮刚度
ktr=492982; %后轮刚度
la=1.1135;lb=1.5415; %前轴、后轴距质心距离
a1=1/m+la*la/iz;
a2=1/m-la*lb/iz;
a3=1/m+lb*lb/iz;
A=[0 0 0 0 1 0 -1 0;
    0 0 0 0 0 1 0 -1;
    0 0 0 0 0 0 1 0;
    0 0 0 0 0 0 0 1;
    -a1*kf -a2*kr 0 0 -a1*cf -a2*cr a1*cf a2*cr;
    -a2*kf -a3*kr 0 0 -a2*cf -a3*cr a2*cf a3*cr;
    kf/mf 0 -ktf/mf 0 cf/mf 0 -cf/mf 0;
    0 kr/mr 0 -ktr/mr 0 cr/mr 0 -cr/mr];
B1=[0 0;
    0 0;
    -1 0;
    0 -1;
    0 0;
    0 0;
    0 0;
    0 0];
B2=[0 0;
    0 0;
    0 0;
    0 0;
    a1 a2;
    a2 a3;
    -1/mf 0;
    0 -1/mr];
C1=eye(8);
C2=[-kf/m -kr/m 0 0  -cf/m -cr/m cf/m cr/m;
    la*kf/iz -lb*kr/iz 0 0 lb*cf/iz -lb*cr/iz -la*cf/iz lb*cr/iz];
D2=[1/m 1/m;
    -la/iz lb/iz];
Q=[x(1) 0 0 0 0 0 0 0;
   0 x(2) 0 0 0 0 0 0;
   0 0 0 0 0 0 0 0;
   0 0 0 0 0 0 0 0;
   0 0 0 0 x(3) 0 0 0;
   0 0 0 0 0 x(4) 0 0;
   0 0 0 0 0 0 0 0;
   0 0 0 0 0 0 0 0];
R=[10^(-4) 0;
   0 10^(-4)];
K=lqr(A,B2,Q,R);
t=[0:0.005:50];
%   运行模型
assignin('base','A',A);
assignin('base','B2',B2);
assignin('base','B1',B1);
assignin('base','C1',C1);
assignin('base','K',K);
assignin('base','R',R);
assignin('base','t',t);
[y1,y2,y3,y4]=sim('answer',[0,50]);%模型仿真
%计算适应度函数值
BA=sqrt(sum(y1.*y1)/size(y1,1));
BB=sqrt(sum(y2.*y2)/size(y2,1));
BC=sqrt(sum(y3.*y3)/size(y3,1));
BD=sqrt(sum(y4.*y4)/size(y4,1));
BA_A=1.78;
BB_A=17.28;
BC_A=6.25;
BD_A=1.78;
if (BA>BA_A)||(BB>BB_A)||(BC>BC_A)||(BD>BD_A)
    f=BA/BA_A+BB/BB_A+BC/BC_A+BD/BD_A+10;
else
    f=BA/BA_A+BB/BB_A+BC/BC_A+BD/BD_A;
end