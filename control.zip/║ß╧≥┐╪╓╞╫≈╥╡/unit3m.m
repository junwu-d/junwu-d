mt=1704.7;ms=1526.9;
Iz=3048.1;
a=1.035;b=1.655;er=0.05;ef=-0.05;
Ixz=21.09;h=0.3352;Ix=744;g=9.8;
v=100/3.6;%车速100km/h转为27.78m/s
kf=39515;df=2823;dr=2653;c1=47298;c2=37311
kr=32500;bf=1.535;br=1.535;%将3.2表中的数据输入其中
M=[Iz 0 Ixz 0;0 mt*v -ms*h 0;Ixz -ms*h*v Ix 0;0 0 0 1];
C=[(2*(a^2)*kf+(b^2)*kr)/v 2*(a*kf-b*kr) 0 2*(b*kr*er-a*kf*ef);
    mt*v+2*(a*kf-b*kr)/v 2*(kf+kr) 0 -2*(kf*ef+kr*er);
    -ms*h*v 0 df+dr c1+c2-ms*h*g;
    0 0 -1 0]; 
N=[2*a*kf -bf/2 br/2;2*kf 0 0;
    0 0 0;0 0 0];%计算所需要的MCN矩阵
MN=inv(M);
A=-MN*C;
B=MN*N%将mcn矩阵转化为状态方程所需要的AB矩阵

