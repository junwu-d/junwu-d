mt=1704.7;
Iz=3048.1;
a=1.035;b=1.655;
v=100/3.6;%车速100km/h转为27.78m/s
kf=39515;
kr=32500;
K=48;
tp=0.03;
tao=0.00078;
M=[Iz 0;0 mt*v];
C=[2*((a^2)*kf+(b^2)*kr)/v 2*(a*kf-b*kr);
    mt*v+2*(a*kf-b*kr)/v 2*(kf+kr)]; 
N=[2*a*kf;
    2*kf];%计算所需要的MCN矩阵
MN=inv(M);
A=-MN*C;
B=MN*N;%将mcn矩阵转化为状态方程所需要的AB矩阵
C2=[1 0;0 1];