figure
plot(P(:,1),P(:,2),'b--',LineWidth=1);
hold on
plot(P1(:,1),P1(:,2),'r',LineWidth=1);
xlabel('5s内水平位移x/m');ylabel('5s内竖直位移y/m');
legend('未施加控制','施加控制');
