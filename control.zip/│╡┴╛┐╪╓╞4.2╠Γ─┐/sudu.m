%将速度分为3个模糊集ze p n
%采用三角隶属函数进行模糊化
N=2;
Z=0:0.01:100;   
for i=1:N+1
    f(i)=100/N*(i-1);
end
u=trimf(Z,[f(1),f(1),f(2)]);
figure
plot(Z,u);
for j=2:N
    u=trimf(Z,[f(j-1),f(j),f(j+1)]);
    hold on
    plot(Z,u);
end
u=trimf(Z,[f(j),f(j+1),f(j+1)]);
hold on
plot(Z,u);
xlabel('Z');
ylabel('速度隶属');
