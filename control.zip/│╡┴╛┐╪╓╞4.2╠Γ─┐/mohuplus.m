clc;
clear all
%%创建模糊控制器

fis = mamfis('Name',"tipper");

%输入车身加速度
fis = addInput(fis, [0 100], 'Name',"input1");
fis = addMF(fis, "input1", "trimf", [0,0,25],'Name',"NM");
fis = addMF(fis, "input1", "trimf", [0,25,50],'Name',"NS");
fis = addMF(fis, "input1", "trimf", [25,50,75],'Name',"ZE");
fis = addMF(fis, "input1", "trimf", [50,75,100],'Name',"PS");
fis = addMF(fis, "input1", "trimf", [75,100,100],'Name',"PM");
%输入速度
fis = addInput(fis, [0 100], "Name","input2");
fis = addMF(fis, "input2", "trimf", [0,0,50],'Name',"N");
fis = addMF(fis, "input2", "trimf", [0,50,100],'Name',"ZE");
fis = addMF(fis, "input2", "trimf", [50,100,100],'Name',"P");

%输入车身与车轮的相对速度
fis = addInput(fis, [0 100], "Name","input3");
fis = addMF(fis, "input3", "trimf", [0,0,25],'Name',"NM");
fis = addMF(fis, "input3", "trimf", [0,25,50],'Name',"NS");
fis = addMF(fis, "input3", "trimf", [25,50,75],'Name',"ZE");
fis = addMF(fis, "input3", "trimf", [50,75,100],'Name',"PS");
fis = addMF(fis, "input3", "trimf", [75,100,100],'Name',"PM");
%输出作用力 
fis = addOutput(fis,[0 100],"Name","output");
fis = addMF(fis, "output", "trimf", [0,0,12.5],'Name',"NV");
fis = addMF(fis, "output", "trimf", [0,12.5,25],'Name',"NB");
fis = addMF(fis, "output", "trimf", [12.5,25,37.5],'Name',"NM");
fis = addMF(fis, "output", "trimf", [25,37.5,50],"Name","NS");
fis = addMF(fis, "output", "trimf", [37.5,50,62.5],'Name',"ZE");
fis = addMF(fis, "output", "trimf", [50,62.5,75],'Name',"PS");
fis = addMF(fis, "output", "trimf", [62.5,75,87.5],'Name',"PM");
fis = addMF(fis, "output", "trimf", [75,87.5,100],'Name',"PB");
fis = addMF(fis, "output", "trimf", [87.5,100,100],'Name',"PV");

%%规则库
ruleList=[5 5 2 5 1 1;%%添加规则表
4 5 2 4 1 1;
3 5 2 3 1 1;
2 5 2 3 1 1;
1 5 2 2 1 1;
5 4 2 5 1 1;
4 4 2 4 1 1;
3 4 2 4 1 1;
2 4 2 3 1 1;
1 4 2 3 1 1;
5 3 2 6 1 1;
4 3 2 5 1 1;
3 3 2 5 1 1;
2 3 2 5 1 1;
1 3 2 4 1 1;
5 2 2 7 1 1;
4 2 2 7 1 1;
3 2 2 6 1 1;
2 2 2 6 1 1;
1 2 2 5 1 1;
5 1 2 8 1 1;
4 1 2 7 1 1;
3 1 2 7 1 1;
2 1 2 6 1 1;
1 1 2 5 1 1;
5 5 -2 4 1 1;
4 5 -2 3 1 1;
3 5 -2 2 1 1;
2 5 -2 2 1 1;
1 5 -2 1 1 1;
5 4 -2 4 1 1;
4 4 -2 3 1 1;
3 4 -2 3 1 1;
2 4 -2 2 1 1;
1 4 -2 2 1 1;
5 3 -2 7 1 1;
4 3 -2 6 1 1;
3 3 -2 5 1 1;
2 3 -2 4 1 1;
1 3 -2 3 1 1;
5 2 -2 8 1 1;
4 2 -2 8 1 1;
3 2 -2 7 1 1;
2 2 -2 7 1 1;
1 2 -2 6 1 1;
5 2 -2 9 1 1;
4 2 -2 8 1 1;
3 2 -2 8 1 1;
2 2 -2 7 1 1;
1 2 -2 6 1 1;];

%%求解
fis = addRule(fis,ruleList);            %%添加模糊规则函数
           
% fis.DefuzzMethod="centroid";                  %设置解模糊方法
% 
% 
% %推理
% input1=0.5;
% input2=0.6;
% input3=0.7;
% output1=evalfis(fis,[input1,input2,input3]);
% 
% %画出模糊系统
% figure(1); plotfis(b2);  
% figure(2);plotmf(fis,'input1',1);
% figure(3);plotmf(fis,'input2',2);
% figure(4);plotmf(fis,'input3',3);
% figure(5);plotmf(fis,'output',1);


