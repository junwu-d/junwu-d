%输入所需参数求取ABG矩阵
ms=330;mu=25;ks=13000;kt=170000;cs=1000;
A=[0 1 0 -1;
    -ks/ms -cs/ms 0 cs/ms;
    0 0 0 1;
    ks/mu cs/mu -kt/mu -cs/mu];
B=[0;1/ms;0;-1/mu];
G=[0;0;-1;0];
t=0:0.01:4
z0=fdhs(t);
d0=[t(1,:);z0(1,:)];
Z0=d0';%阶跃输入函数