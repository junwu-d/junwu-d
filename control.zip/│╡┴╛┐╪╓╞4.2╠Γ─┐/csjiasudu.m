%将车身加速度分为5个模糊集NM、NS、ZE、PS、PM
%采用三角隶属函数进行模糊化
N=4;
Y=0:0.01:100;   
for i=1:N+1
    f(i)=100/N*(i-1);
end
u=trimf(Y,[f(1),f(1),f(2)]);
figure
plot(Y,u);
for j=2:N
    u=trimf(Y,[f(j-1),f(j),f(j+1)]);
    hold on
    plot(Y,u);
end
u=trimf(Y,[f(j),f(j+1),f(j+1)]);
hold on
plot(Y,u);
xlabel('Y');
ylabel('车身加速度隶属');
