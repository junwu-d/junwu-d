%将主动悬架产生的力分为9个模糊集NV、NB、NM、NS、ZE、PS、PM、PB、PV
%采用三角隶属函数进行模糊化
N=8;
a=0:0.01:100;   
for i=1:N+1
    f(i)=100/N*(i-1);
end
u=trimf(a,[f(1),f(1),f(2)]);
figure
plot(a,u);
for j=2:N
    u=trimf(a,[f(j-1),f(j),f(j+1)]);
    hold on
    plot(a,u);
end
u=trimf(a,[f(j),f(j+1),f(j+1)]);
hold on
plot(a,u);
xlabel('a');
ylabel('作动器作用力');